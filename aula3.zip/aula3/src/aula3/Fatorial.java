/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Fatorial {
    
    public static void main(String[] args) {
        double numero;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Digite o número:");
        numero = Double.parseDouble(entrada);
        
        long fatorial = 1;
        for (int i = 1; i<= numero; i++){
            fatorial *= i;
        }
        JOptionPane.showMessageDialog(null, "O fatorial de" + numero + "é" + fatorial );

    }
}
