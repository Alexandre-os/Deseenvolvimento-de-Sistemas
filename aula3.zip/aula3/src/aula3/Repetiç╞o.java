/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Repetição {
	public static void main (String args[]){
		int A, B, C, maior, menor, result, result2;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
                A = Integer.parseInt(entrada);                                   
		entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
                B = Integer.parseInt(entrada);                                   
		entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
                C = Integer.parseInt(entrada);
        
        if (A <= 0 && B <= 0 && C <= 0){
               JOptionPane.showMessageDialog(null, "O valor digitado não é válido!");
               
               entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
               A = Integer.parseInt(entrada);                                   
               entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
               B = Integer.parseInt(entrada);                                   
               entrada = JOptionPane.showInputDialog("Informe um número inteiro maior que 0:");
               C = Integer.parseInt(entrada);
               
               if (A > 0 && B > 0 && C > 0){
			if (A > B && A > C && B < C){
				maior = A;
				menor = B;
				
				result = menor * maior;
				result2 = maior / menor;
				JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
			}
				else {
					if (A > B && A > C && B > C){
						maior = A;
						menor = C;
				
						result = menor * maior;
						result2 = maior / menor;
						JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
					}
				}
		}
			else {
				if (B > A && B > C && A < C){
					maior = B;
					menor = A;
				
					result = menor * maior;
					result2 = maior / menor;
					JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
				}
					else {
						if (B > A && B > C && A > C){
							maior = B;
							menor = C;
				
							result = menor * maior;
							result2 = maior / menor;
							JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
						}
					}
			}
				if (C > A && C > B && A < B){
					maior = C;
					menor = A;
				
					result = menor * maior;
					result2 = maior / menor;
					JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
				}
					else {
						if (C > A && C > B && A > B){
							maior = C;
							menor = B;
				
							result = menor * maior;
							result2 = maior / menor;
							JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
						}
					}
        }
		
		if (A > 0 && B > 0 && C > 0){
			if (A > B && A > C && B < C){
				maior = A;
				menor = B;
				
				result = menor * maior;
				result2 = maior / menor;
				JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
			}
				else {
					if (A > B && A > C && B > C){
						maior = A;
						menor = C;
				
						result = menor * maior;
						result2 = maior / menor;
						JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
					}
				}
		}
			else {
				if (B > A && B > C && A < C){
					maior = B;
					menor = A;
				
					result = menor * maior;
					result2 = maior / menor;
					JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
				}
					else {
						if (B > A && B > C && A > C){
							maior = B;
							menor = C;
				
							result = menor * maior;
							result2 = maior / menor;
							JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
						}
					}
			}
				if (C > A && C > B && A < B){
					maior = C;
					menor = A;
				
					result = menor * maior;
					result2 = maior / menor;
					JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
				}
					else {
						if (C > A && C > B && A > B){
							maior = C;
							menor = B;
				
							result = menor * maior;
							result2 = maior / menor;
							JOptionPane.showMessageDialog(null, "Resultado:" + " " + result + " , " + result2);
						}
					}
       }
}