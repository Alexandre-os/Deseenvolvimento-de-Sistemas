/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Boletim {
	public static void main (String args[]){
		double media, recuperacao, novaMedia, nota1, nota2, nota3, nota4;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe a primeira nota:");
        nota1 = Double.parseDouble(entrada);
		entrada = JOptionPane.showInputDialog("Informe a segunda nota:");
        nota2 = Double.parseDouble(entrada);
		entrada = JOptionPane.showInputDialog("Informe a terceira nota:");
        nota3 = Double.parseDouble(entrada);
		entrada = JOptionPane.showInputDialog("Informe a quarta nota:");
        nota4 = Double.parseDouble(entrada);
		
		media = (nota1 + nota2 + nota3 + nota4) / 4;
		
		if (media >= 7){
			JOptionPane.showMessageDialog(null, "Você foi aprovado!" + " " + "Sua média é:" + " " + media);
		}
			else {
				if (media < 7){
					entrada = JOptionPane.showInputDialog("Informe sua nota de Recuperação:");
					recuperacao = Double.parseDouble(entrada);
					
					novaMedia = recuperacao + media;
					
						if (novaMedia >= 7){
							JOptionPane.showMessageDialog(null, "Você foi aprovado na Recuperação!" + " " + "Sua média é:" + " " + novaMedia);
						}
							else {
								JOptionPane.showMessageDialog(null, "Você não foi aprovado!" + " " + "Sua média é:" + " " + novaMedia);
							}
				}
			}
	}
}
