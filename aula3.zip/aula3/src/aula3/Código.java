/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Código {
	public static void main (String args[]){
		int CODIGO;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro de 1 a 3:");
                CODIGO = Integer.parseInt(entrada);
		
		switch(CODIGO){
			case 1: JOptionPane.showMessageDialog(null, "um"); break;
			case 2: JOptionPane.showMessageDialog(null, "dois"); break;
			case 3: JOptionPane.showMessageDialog(null, "três"); break;
			default:
				JOptionPane.showMessageDialog(null, "Valor Inválido");
			break;
		}
	}
}