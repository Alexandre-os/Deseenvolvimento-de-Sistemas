/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Alun
 */
public class Numeros_Impares {
        public static void main(String[] args) {
    
        for (int i = 101; i < 200; i += 2) {
            JOptionPane.showMessageDialog(null, i);
        }
        
        
       }
}
