/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Positivo {
	public static void main (String args[]){
		int A, B, C;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número:");
        C = Integer.parseInt(entrada);
		
		if (C == 0) {
			JOptionPane.showMessageDialog(null,"O seu valor" + " " + C + " " + "é neutro");
		}
			if (C > 0) {
				A = C;
				JOptionPane.showMessageDialog(null,"O seu valor" + " " + A + " " + "é positivo");
			}
				else {
					if (C < 0) {
						B = C;
						JOptionPane.showMessageDialog(null,"O seu valor" + " " + B + " " + "é negativo");
					}
				}
	
	}
}
