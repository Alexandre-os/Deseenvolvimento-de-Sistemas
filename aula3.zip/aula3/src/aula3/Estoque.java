/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Estoque {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double qtdeMin, qtdeMax, estoque;
        String entrada;
        
        //entrada de dados
        entrada = JOptionPane.showInputDialog("Digite a quantidade mínimo:");
        qtdeMin = Double.parseDouble(entrada);
        
        entrada = JOptionPane.showInputDialog("Digite a quantidade maxímo:");
        qtdeMax = Double.parseDouble(entrada);
        
        //processamento
        estoque = (int) (qtdeMin + qtdeMax)/2;
        
        //saída
        JOptionPane.showMessageDialog(null, "O valor do estoque é:" + estoque);
    }
    
}
