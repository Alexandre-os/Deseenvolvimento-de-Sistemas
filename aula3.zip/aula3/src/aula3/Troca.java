/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Troca {
	public static void main (String args[]){
		int A, B, C;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        A = Integer.parseInt(entrada);
        entrada = JOptionPane.showInputDialog("Informe outro número inteiro:");
        B = Integer.parseInt(entrada);
		
		C = A;
		A = B;
		B = C;
		
		JOptionPane.showMessageDialog(null,"Os valores são:" + " " + A + " e " + B);

	}
}