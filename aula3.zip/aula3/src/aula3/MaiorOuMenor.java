/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class MaiorOuMenor {
	public static void main (String args[]){
		int M, N;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número:");
        M = Integer.parseInt(entrada);
		entrada = JOptionPane.showInputDialog("Informe um outro número:");
        N = Integer.parseInt(entrada);
		
		if (M == N){
			JOptionPane.showMessageDialog(null, "Os dois números são iguais:" + " " + M + " = " + N);
		}
		
			if (M > N){
				JOptionPane.showMessageDialog(null, "O maior número é:" + " " + M + " " + "e o Menor número é" + " " + N);
			}
				else {
					if (N > M){
						JOptionPane.showMessageDialog(null, "O maior número é:" + " " + N + " " + "e o Menor número é" + " " + M);
					}
				}
	}
}
