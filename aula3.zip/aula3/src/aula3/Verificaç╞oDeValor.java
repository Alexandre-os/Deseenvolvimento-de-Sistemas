/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class VerificaçãoDeValor {
	public static void main (String args[]){
		int nrm;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro entre 0 e 9:");
        nrm = Integer.parseInt(entrada);
		
		if (nrm >= 0 && nrm <= 9){
			JOptionPane.showMessageDialog(null, "Valor Válido, seu valor: " + nrm);
		}
			else {
				JOptionPane.showMessageDialog(null, "Valor Inválido, seu valor: " + nrm);
			}
	}
}