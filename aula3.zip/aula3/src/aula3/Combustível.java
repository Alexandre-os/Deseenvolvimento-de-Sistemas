/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Combustível {
    public static void main (String args[]){
        double velo_media, tempo_gasto, distancia, litros_usados, tempo_horas;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Informe o Tempo gasto em Minutos:");
        tempo_gasto = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe a Velocidade Média:");
        velo_media = Double.parseDouble(entrada);
        
        tempo_horas = tempo_gasto / 60;
        distancia = tempo_horas * velo_media;
        litros_usados = distancia / 12;
        
        JOptionPane.showMessageDialog(null, "A viagem com duração de" + " " + tempo_horas + " " +
               "horas na velocidade média de" + " " + velo_media + " " +
               "km/h percorrendo a distância de" +" " + distancia + " "+
               "km consumiu " + litros_usados + " " + "litros");
    }
}
