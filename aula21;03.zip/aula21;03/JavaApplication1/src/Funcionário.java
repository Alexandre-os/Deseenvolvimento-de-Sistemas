/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Funcionário {
    String nomeFunc;
    char cpf;
    String cargo;
    char diaContratado;
    double salario;
    char idadeF;
}
