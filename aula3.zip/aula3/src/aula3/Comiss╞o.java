/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Comissão {
    public static void main (String args[]) {
        double id_vendedor, id_peca, preco_un, qtd_vendida, comissao;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Informe o id de vendedor:");
        id_vendedor = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe o código da peça:");
        id_peca = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe o preço unitário da peça:");
        preco_un = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe a quantidade vendida:");
        qtd_vendida = Double.parseDouble(entrada);
        
        comissao = ((preco_un * qtd_vendida) / 10) / 2;
        
        JOptionPane.showMessageDialog(null, "O vendedor " + " " + id_vendedor + " " +
               "recebeu a comissão" + " " + comissao + " " +
               "por vender a peça" +" " + id_peca + " "+
               "na quantidade de " + qtd_vendida + " " + "peças");
    }
}
