/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Decrescente {
	 public static void main (String args[]){
		int n1, n2, n3;
		String entrada;
			
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        n1 = Integer.parseInt(entrada);
		entrada = JOptionPane.showInputDialog("Informe um outro número inteiro:");
        n2 = Integer.parseInt(entrada);
		entrada = JOptionPane.showInputDialog("Informe mais um número inteiro:");
        n3 = Integer.parseInt(entrada);
		
		if (n1 == n2 && n2 == n3){
			JOptionPane.showMessageDialog(null, "Deu errado, escolha 3 números diferentes");
		}
			else {
				if (n1 > n2 && n2 > n3) {
					JOptionPane.showMessageDialog(null, " " + n1 + " " + n2 + " " + n3);	
				}
					else {
						if (n2 > n1 && n1 > n3) {
							JOptionPane.showMessageDialog(null, " " + n2 + " " + n1 + " " + n3);
						}
							else {
								if (n3 > n1 && n1 > n2)  {
									JOptionPane.showMessageDialog(null, " " + n3 + " " + n1 + " " + n2);
								} 
									else {
										if (n3 > n2 && n2 > n1)  {
											JOptionPane.showMessageDialog(null, " " + n3 + " " + n2 + " " + n1);
										}
											else {
												if (n2 > n3 && n3 > n1)  {
													JOptionPane.showMessageDialog(null, " " + n2 + " " + n3 + " " + n1);
												}
													else {
														if (n1 > n3 && n3 > n2) {
															JOptionPane.showMessageDialog(null, " " + n1 + " " + n3 + " " + n2);
														}
												}
											}	
									}
							}
					}
			
			}
         }
}