/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class Dolar {
    public static void main(String[] args) {
        double cot_dolar,vlr_dolar,vlr_real;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Digite a cotação atual do dolar");
        cot_dolar = Double.parseDouble(entrada);
        
        entrada = JOptionPane.showInputDialog("Digite o valor em dolares");
        vlr_dolar = Double.parseDouble(entrada);
        
        vlr_real = vlr_dolar * cot_dolar;
        
        JOptionPane.showMessageDialog(null,"O valor em Reais é:" + vlr_real);
    }
}
