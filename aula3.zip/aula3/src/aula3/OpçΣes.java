/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Opções {
	public static void main (String args[]){
		int n1, n2, media;
		String entrada, opcao;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        n1 = Integer.parseInt(entrada);
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        n2 = Integer.parseInt(entrada);
		opcao = JOptionPane.showInputDialog("Escolha: Múltiplos(1), Pares(2), Média maior ou igual a 7(3), sair(4)");
		
		switch (opcao){
			case "1":
				if (n1 % n2 == 0 && n2 != 0){
					JOptionPane.showMessageDialog(null, "O" + " " + n1 + " é múltiplo do" + " " + n2);
				}
					else {
						if (n2 % n1 == 0 && n1 != 0){
							JOptionPane.showMessageDialog(null, "O" + " " + n2 + " é múltiplo do" + " " + n1);
						}
							else {
								JOptionPane.showMessageDialog(null, "Nenhum dos números lidos é múltiplo do outro");
							}
					}
			break;
			case "2":
				if (n1 % 2 == 0 && n2 % 2 == 0){
					JOptionPane.showMessageDialog(null, "Ambos os números são pares");
				}
					else {
						JOptionPane.showMessageDialog(null, "Ambos os números não são pares");
					}
			break;
			case "3":
				media = (n1 + n2) / 2;
				if (media >= 7){
					JOptionPane.showMessageDialog(null, "A média dos dois números é maior ou igual a 7: " + media);
				}
					else {
						JOptionPane.showMessageDialog(null, "A média dos dois números não é maior ou igual a 7: " + media);
					}
			break;
			case "4":
				System.exit(0);
			break;
			default:
				JOptionPane.showMessageDialog(null, "Escolha Inexistente!");
			break;
		}
	}
}