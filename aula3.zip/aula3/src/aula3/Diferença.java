/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Diferença {
	 public static void main (String args[]){
		int nL, nH, result;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número:");
        nL = Integer.parseInt(entrada);
        entrada = JOptionPane.showInputDialog("Informe um outro número:");
        nH = Integer.parseInt(entrada);
		
		if (nL > nH) {
			result = nL - nH;
			JOptionPane.showMessageDialog(null, "A Diferença do Maior para o Menor é:" + " " + result);
		}
			else {
				if (nH > nL) {
					result = nH - nL;
					JOptionPane.showMessageDialog(null, "A Diferença do Maior para o Menor é:" + " " + result);
				}
			}

	}
}