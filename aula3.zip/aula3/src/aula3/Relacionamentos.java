package aula3;
import javax.swing.JOptionPane;

public class Relacionamentos {
public static void main (String args[]){
        int n1, n2;
		String result = "";
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        n1 = Integer.parseInt(entrada);
		 entrada = JOptionPane.showInputDialog("Informe outro número inteiro:");
        n2 = Integer.parseInt(entrada);
		
		if (n1 == n2){
			result += "igual. \n";
			result += " " + n1 + " é maior ou igual a \n" + n2 + " , "; 
			result += " " + n1 + " é menor ou igual a  \n" + n2 + " . ";
		}
		if (n1 > n2){
			result += " " + n1 + " é maior que  \n" + n2 + " , ";
			result += " " + n1 + " é maior ou igual a  \n" + n2 + " , ";
		}
		if (n2 > n1){
			result += " " + n2 + " é maior que  \n" + n1 + " , ";
			result += " " + n2 + " é maior ou igual a  \n" + n1 + " , ";
		}
		if (n1 < n2){
			result += " " + n1 + " é menor que  \n" + n2 + " , ";
			result += " " + n1 + " é menor ou igual a \n" + n2 + " , ";
		}
		if (n2 < n1){
			result += " " + n2 + " é menor que \n" + n1 + " , ";
			result += " " + n2 + " é menor ou igual a \n" + n1 + " , ";
		}
		if (n1 != n2){
			result += "não igual. \n";
		}
		       
        JOptionPane.showMessageDialog(null,"Os relacionamentos desses números são: " + result);
    }
}