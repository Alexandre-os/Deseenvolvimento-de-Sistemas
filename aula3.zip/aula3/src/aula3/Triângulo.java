/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Triângulo {
	public static void main (String args[]){
		double A, B, C;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um dos lados do triângulo:");
        A = Double.parseDouble(entrada);
		entrada = JOptionPane.showInputDialog("Informe outro lado do triângulo:");
        B = Double.parseDouble(entrada);
		entrada = JOptionPane.showInputDialog("Informe outro lado do triângulo:");
        C = Double.parseDouble(entrada);
		
		if (A < B + C && B < A + C && C < A + B){
			if (A == B && B == C){
				JOptionPane.showMessageDialog(null, "Este triângulo é Equilátero!");
			}
				else {
					if (A == B || A == C || B == C){
						JOptionPane.showMessageDialog(null, "Este Triângulo é Isósceles");
					}
						else {
							JOptionPane.showMessageDialog(null, "Este Triângulo é Escaleno");
						}
				}
		}
			else {
				JOptionPane.showMessageDialog(null, "Os lados fornecidos não caracterizam um triângulo!");
			}
	}
}