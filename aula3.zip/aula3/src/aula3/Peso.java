/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Peso {
	public static void main (String args[]){
		double h, result;
		String entrada, sexo;
		
		entrada = JOptionPane.showInputDialog("Informe sua altura em metros:");
                h = Double.parseDouble(entrada);
		sexo = JOptionPane.showInputDialog("Informe seu sexo: (M) ou (F)");
		
		switch(sexo){
			case "M":
				result = (72.7 * h) - 58;
				JOptionPane.showMessageDialog(null, "O peso ideal é:" + result);
			break;
			case "F":
				result = (62.1 * h) - 44.7;
				JOptionPane.showMessageDialog(null, "O peso ideal é:" + result);
			break;
			default:
				JOptionPane.showMessageDialog(null, "Escolha de sexo errada!");
			break;
		}
	}
}