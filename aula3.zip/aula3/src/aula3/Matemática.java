/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Matemática {
	public static void main (String args[]){
		int A, B, result;
		String entrada, sinal;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        A = Integer.parseInt(entrada);
		entrada = JOptionPane.showInputDialog("Informe um número inteiro:");
        B = Integer.parseInt(entrada);
		sinal = JOptionPane.showInputDialog("Escolha entre Adição(+), Subtração(-), Multiplicação(x) ou Divisão(/)");
		
		switch (sinal){
			case "+": 
				result = A + B; 
				JOptionPane.showMessageDialog(null, "O resultado é:" + " " + result); 
			break;
			case "-": 
				result = A - B;
				JOptionPane.showMessageDialog(null, "O resultado é:" + " " + result); 
			break;
			case "x": 
				result = A * B; 
				JOptionPane.showMessageDialog(null, "O resultado é:" + " " + result); 
			break;
			case "/":
				if(B != 0){
					result = A / B;
					JOptionPane.showMessageDialog(null, "O resultado é:" + " " + result); 
				}
					else {
						JOptionPane.showMessageDialog(null, "Não pode dividir um número por zero");
					}
			break;
			default:
				JOptionPane.showMessageDialog(null, "Operador Inválido");
			break;
		}
	}
}