/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Volume_óleo {
    public static void main (String args[]){
        double V, R, A;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Informe o Raio do Diâmetro da lata de óleo:");
        R = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe a Altura da lata de óleo:");
        A = Double.parseDouble(entrada);
        
        V = 3.14159 * R * R * A;
        
        JOptionPane.showMessageDialog(null, "O Volume da lata de óleo é " + V);
    }
}
