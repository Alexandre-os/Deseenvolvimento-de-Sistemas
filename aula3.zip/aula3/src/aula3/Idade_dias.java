/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Idade_dias {
     public static void main (String args[]){
         double anos, meses, dias, result_dias, anos_dias, meses_dias;
         String entrada;
         
        entrada = JOptionPane.showInputDialog("Informe quantos anos você tem:");
        anos = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe quantos meses você tem:");
        meses = Double.parseDouble(entrada);
        entrada = JOptionPane.showInputDialog("Informe quantos dias você tem:");
        dias = Double.parseDouble(entrada);
            
        anos_dias = anos * 365;
        meses_dias = meses * 30;
        result_dias = anos_dias + meses_dias + dias;
        
        JOptionPane.showMessageDialog(null, "Sua idade em dias são " + result_dias);
     }
}
