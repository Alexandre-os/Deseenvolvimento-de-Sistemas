/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Parar_Execução {
	public static void main (String args[]){
		int L;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("(O número 0 serve para parar de executar o programa!), Informe um número:");
        L = Integer.parseInt(entrada);
		
			if (L > 0) {
				JOptionPane.showMessageDialog(null, "O seu valor" + " " + L + " " + "é positivo");
			}
				else {
					if (L < 0) {
						JOptionPane.showMessageDialog(null, "O seu valor" + " " + L + " " + "é negativo");
					}
				}
			if (L == 0) {
				System.exit(0);
			}
	}
}