/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class numerosInferno {
     public static void main(String[] args){
         int a,b,c,d,result;
         String entrada;
         
        entrada = JOptionPane.showInputDialog("Digite o valor A");
        a =  Integer.parseInt(entrada);
        entrada = JOptionPane.showInputDialog("Digite o valor B");
        b = Integer.parseInt(entrada);
        entrada = JOptionPane.showInputDialog("Digite o valor C");
        c = Integer.parseInt(entrada);
        entrada = JOptionPane.showInputDialog("Digite o valor D");
        d = Integer.parseInt(entrada);

       result = a*b + a*c + a*d + b*a + b*c + b*d + c*a + c*b + c * d + d*a + d*b + d*c;
       
       JOptionPane.showMessageDialog(null, "O resultado " + result);

    }  
}
