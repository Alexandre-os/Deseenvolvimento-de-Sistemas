/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Conversão_de_graus {
    public static void main (String args[]){
        double F, C;
        String entrada;
        
        entrada = JOptionPane.showInputDialog("Informe os graus em Celsius:");
        C = Double.parseDouble(entrada);
        
        F = (9 * C + 160) / 5;
        
        JOptionPane.showMessageDialog(null,"Os graus em Fahrenheit são: " + F);
    }
}
