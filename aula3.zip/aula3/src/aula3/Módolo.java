/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula3;
import javax.swing.JOptionPane;
/**
 *
 * @author Aluno
 */
public class Módolo {
	public static void main (String args[]){
		int x, result;
		String entrada;
		
		entrada = JOptionPane.showInputDialog("Informe um número inteiro");
        x = Integer.parseInt(entrada);
		
			if (x >= 0) {
			JOptionPane.showMessageDialog(null, "O módolo de" + " " + x + " é " + x);
		}
		else {
			if (x < 0) {
				result = x * (-1);
				JOptionPane.showMessageDialog(null, "O módolo de" + " " + x + " é " + result);
			}
		}
	}
}